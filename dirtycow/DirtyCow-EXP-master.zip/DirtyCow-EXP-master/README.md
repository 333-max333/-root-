# DirtyCow-EXP
编译好的脏牛漏洞（CVE-2016-5195）EXP，分为 Linux 平台 和 Android 平台。

漏洞详细复现过程请参考：  https://brucetg.github.io/2018/05/27/DirtyCow%EF%BC%88%E8%84%8F%E7%89%9B%EF%BC%89%E6%BC%8F%E6%B4%9E%E5%A4%8D%E7%8E%B0/
